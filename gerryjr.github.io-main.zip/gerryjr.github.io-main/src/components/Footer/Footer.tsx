export default function Footer() {
  return (
    <footer>
      <p>&copy; Last Updated June 2025 by Gerardo Lopez Jr.</p>
    </footer>
  );
}